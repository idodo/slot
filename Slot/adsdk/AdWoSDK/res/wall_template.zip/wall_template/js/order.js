
var attributeString;

window.onload = function(){
    window.location = "adwo://adwoFetchSubmitAttributes";
}

function adwoFetchAttributesString(attrStr)
{
    attributeString = attrStr;
}
$(function() {
    //loadProData();

    $("#submit").bind('click', function() {
        // track
        //track(pageid, orderBtnClicked);        
        submitData();
    });
    		if(!is_ios_lower()){
				document.getElementsByClassName("header")[0].classList.add("ios_bug");	
				document.getElementsByClassName("container")[0].classList.add("ios_bug");	
			}

    // track
    //track(pageid, homePV);
});
var isSubmit = false;
function submitData() {
    showAlert("<em style='margin-top:17px;display:block;'>正在提交您的反馈意见..</em>");
	$(".alertMsg-button").hide();
	if(isSubmit){
        return	
	}
	isSubmit = true;
    var app_id = $("#expand1").val(),app_name = $("#expand1 option:selected").text(),description = $("#description").val(), email = $("#email").val(),reg_email = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/;
    var feedbacktype = $(".feedbacktype.selected").text();
    if (!app_id || app_id==="" || app_id==="请选择App名称") {
        showAlert("请选择App名称");isSubmit = false;$(".alertMsg-button").show();
        return
    }
    if (!description || description==="请填写反馈意见") {
        showAlert("请填写反馈意见");isSubmit = false;$(".alertMsg-button").show();
        return
    }
    if (!email || !reg_email.test(email)) {
        showAlert("请填写正确邮箱");isSubmit = false;$(".alertMsg-button").show();
        return
    }

    var url = "http://track.mobile1.com.cn/advmessage/adv/addResultJsonP.action?advid=115&1=1" + attributeString;

    $.ajax({
        url : url,
        cache : false,
		timeout:8000,
        dataType : 'jsonp',
        jsonpCallback : "eventcallback",
        data : {
           expand1 : app_name,
		   expand2 : app_id,
		   expand3 : feedbacktype,
           description : description,
           email : email
        },
        success : function(json) {
			
            if (json[0].success == 1) {
                showAlert("谢谢，反馈意见提交成功！",function(){history.back();});
				isSubmit = false;$(".alertMsg-button").show();
            } else {
                showAlert(json[0].info);
				isSubmit = false;$(".alertMsg-button").show();
            }
        },
		error: function(){
			showAlert("提交超时，请再试一次");
			isSubmit = false;$(".alertMsg-button").show();
		}
    });
}
function showAlert(msg,fun){
	document.getElementsByClassName('cover').item(0).style.height = document.height+"px";
	document.getElementsByClassName('alertMsg').item(0).classList.remove("popShakeOut");
	document.getElementsByClassName('alertMsg').item(0).classList.add("popShakeIn");
	document.getElementsByClassName('alertMsg').item(0).style.display = "block";
	document.getElementsByClassName('cover').item(0).style.display = "block";
	if(msg){
		$("#messageText").html(msg);	
	}
	if(fun){
		$(".alertMsg").bind("click",fun);	
	}
	document.body.addEventListener('touchmove',preventDefault,false);
	
}
function closeAlert(){
	if(!isSubmit){
		document.getElementsByClassName('cover').item(0).style.display = "none";
		document.getElementsByClassName('alertMsg').item(0).classList.remove("popShakeIn");
		document.getElementsByClassName('alertMsg').item(0).classList.add("popShakeOut");
		document.body.removeEventListener('touchmove',preventDefault,false);
		setTimeout("document.getElementsByClassName('alertMsg').item(0).style.display = 'none';",400);
		document.body.removeEventListener('touchmove',preventDefault,false);
	}
}
function preventDefault(event){
	event.preventDefault();
}
	
	

